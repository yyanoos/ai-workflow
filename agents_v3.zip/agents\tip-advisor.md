---
name: tip-advisor
description: 워크플로우 진행 중 사용자에게 유용한 Claude Code 기능을 추천하는 내부 참조 문서
tools: Read
---

# Claude Code 기능 추천 가이드

이 문서는 에이전트가 아니라 **메인 세션이 참조하는 내부 가이드**다.
각 워크플로우의 "여기서 멈춤" 또는 Phase 완료 시점에, 상황에 맞는 tip을 1개 출력한다.

## 규칙

- 매 멈춤마다 tip을 강제하지 않는다 — 관련 있을 때만
- 같은 tip을 반복하지 않는다 — 세션 내 이미 안내한 것은 스킵
- 1줄로 짧게. 자세한 설명이 필요하면 "자세히: /tips hooks" 안내
- `💡 tip:` 접두사로 시작

---

## 상황별 추천 목록

### /dev 관련

| 상황 | tip |
|------|-----|
| Phase 1 완료 (spec 승인) | `💡 tip: 플랜모드(shift+tab)로 구현 전략을 먼저 검토할 수 있어요` |
| Phase 3 시간 오래 걸릴 때 | `💡 tip: 서브에이전트가 작업 중이니 다른 세션에서 /dev "다른 기능" 병렬 가능` |
| Phase 5 완료 (MR 생성) | `💡 tip: hooks로 PR 생성 시 자동 Slack 알림 설정 가능 (settings.json)` |
| 여러 기능 동시 진행 | `💡 tip: /dev --list 로 진행 중인 기능 전체 현황 확인` |

### /qa 관련

| 상황 | tip |
|------|-----|
| Phase 4 승인 반복 | `💡 tip: /loop 5m /qa 로 자동 반복 실행 가능 (승인만 해주면 됨)` |
| 테스트 실패 반복 | `💡 tip: /investigate 로 근본 원인 분석 후 접근하면 효율적` |

### /evolve 관련

| 상황 | tip |
|------|-----|
| 첫 실행 | `💡 tip: /evolve --budget 으로 토큰 예산 현황 확인. --max-time으로 시간 제한 권장` |
| 완료 후 | `💡 tip: report HTML을 브라우저에서 열어 before/after 비교 후 PR 승인/거절` |

### /start 관련

| 상황 | tip |
|------|-----|
| 신규 프로젝트 | `💡 tip: /strategy부터 시작하면 시장 검증 후 개발해서 삽질 방지` |
| 기존 프로젝트 복귀 | `💡 tip: /who 로 현재 단계에 맞는 전문가 확인` |

### 에러 복구

| 상황 | tip |
|------|-----|
| BLOCKED (구현 불가) | `💡 tip: spec 수정이 필요하면 /dev --respec, 직접 해결 후 재시작은 /dev --from 3` |
| FAIL (테스트 3회 실패) | `💡 tip: /qa --retry-failed 로 실패 엔드포인트를 재시도. 원인 파악은 /investigate` |
| ERROR (인프라 문제) | `💡 tip: docker compose -f docker-compose.test.yml down && up -d --wait 로 인프라 초기화` |
| CONFLICT (파일 충돌) | `💡 tip: 충돌 세션이 merged 될 때까지 대기하거나, /dev --list 로 현황 파악` |
| 리뷰 NEEDS_WORK 반복 | `💡 tip: 2차 리뷰까지 NEEDS_WORK면 사람이 판단. 남은 지적사항 확인 후 진행 여부 결정` |

### 범용

| 상황 | tip |
|------|-----|
| 오래 걸리는 작업 시작 | `💡 tip: 백그라운드 에이전트로 돌리면 다른 작업 동시 가능` |
| 반복 작업 감지 | `💡 tip: hooks(settings.json)로 이 패턴 자동화 가능` |
| 복잡한 변경 전 | `💡 tip: 플랜모드(shift+tab)로 설계 먼저 잡으면 실수 줄어듦` |
| 디버깅 중 | `💡 tip: /investigate 로 체계적 디버깅 (가설→검증→수정)` |
| 보안 걱정 | `💡 tip: /security 로 보안감사 가능 (준비 중)` |
| 세션 종료 전 | `💡 tip: /session-docs 로 작업 요약 생성하면 다음 세션 인수인계가 쉬워요` |

---

## Claude Code 핵심 기능 요약 (참조용)

| 기능 | 설명 | 사용법 |
|------|------|--------|
| 플랜모드 | 코드 수정 전 설계/분석만 | `shift+tab` |
| 서브에이전트 | 무거운 작업 병렬 처리 | 커맨드 내부에서 자동 사용 |
| hooks | 특정 이벤트에 자동 실행 | `settings.json`에 설정 |
| /loop | 주기적 반복 실행 | `/loop 10m /qa` |
| /schedule | 크론 기반 스케줄 실행 | 원격 에이전트 예약 |
| 백그라운드 실행 | 긴 작업을 뒤에서 | 에이전트 내부 기능 |
| 멀티 세션 | 여러 터미널에서 동시 | 각 세션이 독립 기능 담당 |
| extended thinking | 복잡한 문제 깊이 생각 | 자동 또는 "think harder" |
